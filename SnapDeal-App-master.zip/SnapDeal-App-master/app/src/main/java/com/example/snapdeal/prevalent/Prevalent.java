package com.example.snapdeal.prevalent;

import com.example.snapdeal.model.Users;

public class Prevalent
{
    public static Users CurrOnlineUser;


    public static final String UserphoneKey="UserPhone";
    public static final String UserpasswordKey="UserPassword";
}
