package com.example.snapdeal.interfaces;

import android.view.View;

public interface itemClickListner
{
    void onClick(View view,int position,boolean isLongClicked);
}
